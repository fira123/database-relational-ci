<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rumahsakit extends CI_Controller {
	public function __construct(){
        parent::__construct();
        $this->load->model("Rumah_Sakit");
    }

	public function index()
	{
		$data["tb_data_pasien"] = $this->Rumah_Sakit->getTable();
        $this->load->view("rumah_sakit.php", $data);	
	}

	 public function create(){
        $this->load->model('d_penyakit');
        $this->load->model('d_status');

        $data['tb_jenis_penyakit'] = $this->d_penyakit->getAll();
        $data['tb_status'] = $this->d_status->getStat();

        $this->load->view('data/create', $data);
    }
    public function save(){
        $this->load->model('rumah_sakit');
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $genre = $this->input->post('genre');
        $penyakit = $this->input->post('penyakit');
        $status = $this->input->post('status');

        $data = [
            'nama' => $nama,
            'jenis_kelamin' => $genre,
            'alamat' => $alamat,
            'id_penyakit' => $penyakit,
            'id_status' => $status
        ];

        $save = $this->rumah_sakit->insert($data);

        if($save) {
            $this->session->set_flashdata('msg_success', 'Data telah tersimpan!');
        } else {
            $this->session->set_flashdata('msg_error', 'Data gagal disimpan, silakan isi ulang!');
        }
        redirect('rumahsakit');
    }

    public function edit($id){
        $this->load->model('d_penyakit');
        $this->load->model('d_status');
        $this->load->model('rumah_sakit');

        $data['tb_jenis_penyakit'] = $this->d_penyakit->getAll();
        $data['tb_status'] = $this->d_status->getStat();

        $data['tb_data_pasien'] = $this->rumah_sakit->get($id);
        $this->load->view('data/edit', $data);
    }

    public function update(){
        $this->load->model('rumah_sakit');
        $id = $this->input->post('id');
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $genre = $this->input->post('genre');
        $penyakit = $this->input->post('penyakit');
        $status = $this->input->post('status');

        $data = [
            'nama' => $nama,
            'jenis_kelamin' => $genre,
            'alamat' => $alamat,
            'id_penyakit' => $penyakit,
            'id_status' => $status
        ];

        $save = $this->rumah_sakit->update($data, $id);

        if($save) {
            $this->session->set_flashdata('msg_success', 'Data telah diubah!');
        } else {
            $this->session->set_flashdata('msg_error', 'Data gagal disimpan, silakan isi ulang!');
        }
        redirect('rumahsakit');
    }

    public function delete($id){
        $this->load->model('rumah_sakit');

        $delete = $this->rumah_sakit->delete($id);

        if ($delete) {
            $this->session->set_flashdata('msg_success', 'Data yang anda pilih telah terhapus');
        } else {
            $this->session->set_flashdata('msg_error', 'Tidak bisa hapus pesan');
        }
        redirect('rumahsakit');
    }

}

/* End of file Rumahsakit.php */
/* Location: ./application/controllers/Rumahsakit.php */