<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class D_status extends CI_Model {

	public function getStat(){
        return $this->db->get('tb_status')->result();
    }

}

/* End of file D_status.php */
/* Location: ./application/models/D_status.php */