<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class D_penyakit extends CI_Model {
public function getAll(){
        return $this->db->get('tb_jenis_penyakit')->result();
    }
	

}

/* End of file D_penyakit.php */
/* Location: ./application/models/D_penyakit.php */