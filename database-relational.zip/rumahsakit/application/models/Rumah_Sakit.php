<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rumah_Sakit extends CI_Model {


/*private $_table = "tb_data_pasien"; 

    public $id_pasien;
    public $nama;
    public $genre;
    public $age;
    public $penyakit;
    public $status;
    */
    public function getTable(){
        $this->db->select('tb_data_pasien.*, tb_jenis_penyakit.nama_penyakit, tb_status.status');
        $this->db->from('tb_data_pasien');
        $this->db->join('tb_jenis_penyakit', 'tb_jenis_penyakit.id = tb_data_pasien.id_penyakit');
        $this->db->join('tb_status', 'tb_status.id = tb_data_pasien.id_status');
        $query = $this->db->get();
        return $query->result();
    }

    public function insert($data){
        return $this->db->insert('tb_data_pasien', $data);
    }

    public function get($id){
        return $this->db->where('id', $id)->get('tb_data_pasien')->row();
    }

    public function  update($data, $id){
        return $this->db->where('id', $id)->update('tb_data_pasien', $data);
    }

    public function delete($id){
        return $this->db->where('id', $id)->delete('tb_data_pasien');
    }
    /*public function getById(){
        return $this->db->get_where($this->_table, ['id_pasien' => $id])->row();
    } */
	

}

/* End of file Rumah_Sakit.php */
/* Location: ./application/models/Rumah_Sakit.php */