<footer class="page-footer font-small blue pt-4 footer" style="position: sticky; bottom: 0; width: 100%">
    <div class="footer-copyright text-center py-3 bg-dark text-white">
        &copy; 2018 Copyright: Rumah Sakit
    </div>
</footer>
