<!DOCTYPE html>
<html>
    <head>
        <?php $this->load->view("_partials/head.php"); ?>
    </head>
    <body>
        <?php $this->load->view("_partials/navbar.php"); ?>
        <div class="container">
            <div class="col-md-9">
                <h3>Tambah data pasien</h3>
                <hr>
                <form action="<?php echo site_url('rumahsakit/save') ?>" method = "post">
                    <div class = "form-group">
                        <label>Nama</label>
                        <input type="text" name="nama" class="form-control">
                    </div>
                    <div class = "form-group">
                        <label>Jenis Kelamin</label>
                        <br>
                        <input type="radio" name="genre" value="Laki-laki">Laki-laki
                        <input type="radio" name="genre" value="Perempuan">Perempuan
                    </div>
                    <div class = "form-group">
                        <label>Alamat</label>
                        <textarea name="alamat" rows="3" class="form-control"></textarea>
                    </div>
                    <div class = "form-group">
                        <label>Jenis Penyakit</label>
                        <select name="penyakit" class="form-control">
                            <?php foreach ($tb_jenis_penyakit as $sakit): ?>
                                <option value="<?php echo $sakit->id ?>"><?php echo $sakit->nama_penyakit ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class = "form-group">
                        <label>Status</label>
                        <select name="status" class="form-control">
                            <?php foreach ($tb_status as $statuss): ?>
                                <option value="<?php echo $statuss->id ?>"><?php echo $statuss->status ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>  
                    <input type="submit" class="btn btn-success" value="Simpan">
                </form>
            </div>
        </div>
        <?php $this->load->view("_partials/footer.php"); ?>
        <!--javascript-->
        <?php $this->load->view("_partials/js.php"); ?>
    </body>
</html>