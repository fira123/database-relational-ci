<nav class="navbar sticky-top navbar-light bg-success">
    <span class="navbar-brand mb-0 h1 text-white ">DATA PASIEN</span>
</nav>
