    <!DOCTYPE html>
<html>
    <head>
        <?php $this->load->view("_partials/head.php"); ?>
    </head>
    <body>
        <?php $this->load->view("_partials/navbar.php"); ?>
        <div class="container">
            <table class="table">
                <legend class="text-center">Tabel Data Pasien</legend>
                <div>
                    <a href="<?php echo site_url('rumahsakit/create') ?>" class="btn btn-success">Tambah</a>
                </div>
                <?php if($this->session->flashdata('msg_success')): ?>
                    <div class="alert alert-success"><?php echo $this->session->flashdata('msg_success') ?></div>
                <?php endif ?>
                <?php if ($this->session->flashdata('msg_error')): ?>
                    <div class="alert alert-danger"><?php echo $this->session->flashdata('msg_error') ?> </div>
                <?php endif ?>
                <br>
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nama</th>
                        <th scope="col">Alamat</th>
                        <th scope="col">Jenis Kelamin</th>
                        <th scope="col">Jenis Penyakit</th>
                        <th scope="col">Status</th>
                        <th scope="col">Kelola</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $no = 1;
                        foreach ($tb_data_pasien as $pasien): ?>
                        <tr>
                            <td>
                                <?php echo $no++?>
                            </td>
                            <td>
                                <?php echo $pasien->nama ?>
                            </td>
                            <td>
                                <?php echo $pasien->jenis_kelamin ?>
                            </td>
                            <td>
                                <?php echo $pasien->alamat ?>
                            </td>
                            <td>
                                <?php echo $pasien->nama_penyakit ?>
                            </td>
                            <td>
                                <?php echo $pasien->status ?>
                            </td>
                            <td>
                                <a href="<?php echo site_url('rumahsakit/edit/'.$pasien->id)?>" class="btn btn-primary">Sunting</a>
                                <a href="<?php echo site_url('rumahsakit/delete/'.$pasien->id)?>" class="btn btn-danger" onclick="return confirm('Apakah kamu yakin?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach;?>
                </tbody>
            </table>
        </div>
        <?php $this->load->view("_partials/footer.php"); ?>
        <!--javascript-->
        <?php $this->load->view("_partials/js.php"); ?>
    </body>
</html>